import matplotlib.pyplot as plt

def plot_rate_performance(capacity_by_cycle, efficiency_by_cycle=None):
    """
    Plot rate performance: specific capacity vs. cycle number,
    with optional Coulombic efficiency on a secondary y-axis.

    Args:
        capacity_by_cycle: dict[int, list[float]]
            keys = current densities (mA g⁻¹),
            values = list of capacities over cycles.
        efficiency_by_cycle: dict[int, list[float]], optional
            same keys as capacity_by_cycle; values = efficiencies (%).
    """
    fig, ax1 = plt.subplots()
    ax1.set_xlabel("Cycle Number")
    ax1.set_ylabel("Specific Capacity (mAh g⁻¹)")

    for rate, caps in sorted(capacity_by_cycle.items()):
        ax1.plot(range(1, len(caps) + 1), caps, label=f"{rate} mA g⁻¹")
    ax1.legend(loc="upper left")

    if efficiency_by_cycle:
        ax2 = ax1.twinx()
        ax2.set_ylabel("Coulombic Efficiency (%)")
        for rate, eff in sorted(efficiency_by_cycle.items()):
            ax2.plot(range(1, len(eff) + 1), eff, linestyle="--", label=f"{rate} CE")
        ax2.legend(loc="upper right")

    fig.tight_layout()
    plt.show()
